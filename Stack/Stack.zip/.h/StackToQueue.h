#include<iostream>
#include<stack>

using namespace std;

class Stack{
	public:
		void push(int x);
		void pop();
		bool empty();
		int top();
	private:
		stack<int> q1, q2;
};

void Stack::push(int x) {
    if (!q1.empty()){
        q2.push(x);
        while (!q1.empty())
        {
            q2.push(q1.top());
            q1.pop();
        }
    }else{
        q1.push(x);
        while (!q2.empty())
        {
        	q1.push(q2.top());
            q2.pop();
        }
    }
}

void Stack::pop(){
	if (q1.empty()&&q2.empty())
        cout<<"stack is empty";
    else if (!q1.empty()) q1.pop();
    else q2.pop();
}

bool Stack::empty(){
	return (q1.empty() &&q2.empty());
}

int Stack::top(){
	if (!q1.empty()) return q1.top();
    else return q2.top();
}

