#ifndef _PET_H
#define _PET_H

#include <string>

using namespace std;

class Pet
{
public:
    Pet(string type)
    {
        this->type = type;
    }
    string getPetType()
    {
        return type;
    }
private:
    string type;
};

class Dog:public Pet
{
public:
    Dog():Pet("dog"){}
};

class Cat:public Pet
{
public:
    Cat():Pet("cat"){}
};
#endif
