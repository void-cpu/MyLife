#include<iostream>
#include<vector>
using namespace std;

class RotationPrintArray{
    public:
        void printEdge(vector< vector<int> >m, int tR, int tC, int dR, int dC);
        void spiralOrderPrint(vector< vector<int> >matrix);
};

void RotationPrintArray::printEdge(vector< vector<int> >m, int tR, int tC, int dR, int dC) {
        if (tR == dR) { // �Ӿ���ֻ��һ��ʱ
            for (int i = tC; i <= dC; i++) {
                cout<<m[tR][i] + " ";
            }
        } else if (tC == dC) { // �Ӿ���ֻ��һ��ʱ
            for (int i = tR; i <= dR; i++) {
                cout<<m[i][tC] + " ";
            }
        } else {// һ�����
            int curC = tC;
            int curR = tR;
            while (curC != dC) {
                cout<<m[tR][curC] + " ";
                curC++;
            }
            while (curR != dR) {
                cout<<m[curR][dC] + " ";
                curR++;
            }
            while (curC != tC) {
                cout<<m[dR][curC] + " ";
                curC--;
            }
            while (curR != tR) {
                cout<<m[curR][tC] + " ";
                curR--;
            }
        }
}

void RotationPrintArray::spiralOrderPrint(vector< vector<int> >matrix) {
    int tR = 0;
    int tC = 0;
    int dR = matrix.size()- 1;
    int dC = matrix[0].size() - 1;
    while (tR <= dR && tC <= dC) {
        printEdge(matrix, tR++, tC++, dR--, dC--);
    }
}
