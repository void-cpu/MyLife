#include<stack>
using namespace std;

class StackToQueue{
    private:
        stack<int> Stack1,Stack2;
    public:
        void EnterStack(int Number);
        bool IsBoolEmpty ();
        void ClearStack();
        int OutStack();
};

void StackToQueue:: EnterStack(int Number){
    Stack1.push(Number);
}

bool StackToQueue::IsBoolEmpty (){
    return Stack1.empty() && Stack2.empty();
}

int StackToQueue::OutStack(){
    int Number;
        
    if (Stack2.empty()) {
         while (!Stack1.empty()) {
            int i = Stack1.top();
            Stack1.pop();
            Stack2.push(i);
        }
    }
    Number = Stack2.top();
    Stack2.pop();
    return Number;
}    
 
