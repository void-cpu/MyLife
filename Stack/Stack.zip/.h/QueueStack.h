#include<iostream>
#include<queue>

using namespace std;

class Stack{
	public:
		void push(int x);
		void pop();
		bool empty();
		int top();
	private:
		queue<int> q1, q2;
};

void Stack::push(int x) {
    if (!q1.empty()){
        q2.push(x);
        while (!q1.empty())
        {
            q2.push(q1.front());
            q1.pop();
        }
    }else{
        q1.push(x);
        while (!q2.empty())
        {
        	q1.push(q2.front());
            q2.pop();
        }
    }
}

void Stack::pop(){
	if (q1.empty()&&q2.empty())
        cout<<"stack is empty";
    else if (!q1.empty()) q1.pop();
    else q2.pop();
}

bool Stack::empty(){
	return (q1.empty() &&q2.empty());
}

int Stack::top(){
	if (!q1.empty()) return q1.front();
    else return q2.front();
}

