#include <iostream>
#include <stack>
using namespace std;

struct Node
{
    int value;
    Node *next;
};
//�����㷨
bool isPalindrome3(Node *head)
{
    if(NULL == head || NULL == head->next)
        return true;
    Node *n1(head),*n2(head);
    while(NULL != n2 && NULL != n2->next)
    {
        n1 = n1->next;    //�ҵ��м�ڵ�
        n2 = n2->next->next;
    }
    n2 = n1->next;    //�Ұ벿�ֵĵ�һ���ڵ�
    n1->next =NULL;
    Node *n3 = NULL;
    while(NULL != n2)    //��ת�Ұ벿������
    {
        n3 = n2->next;
        n2->next = n1;
        n1 = n2;
        n2 = n3;
    }
    n3 = n1;    //��¼���һ���ڵ�
    n2 = head;    //��¼ͷ�ڵ�
    bool res = true;
    while(NULL != n1 && NULL != n2)
    {
        if(n1->value != n2->value)
        {
            res = false;
            break;
        }
        n1 = n1->next;
        n2 = n2->next;
    }
    n1 = n3->next;
    n3->next = NULL;
    while(NULL != n1)
    {
        n2 = n1->next;
        n1->next = n3;
        n3 = n1;
        n1 = n2;
    }
    return res;
}

void printLists(Node *head)
{
    while(NULL != head)
    {
        cout << head->value << " " ;
        head = head->next;
    }
    cout << endl;
}
