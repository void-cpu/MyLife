#ifndef _PETSTAMP_H
#define _PETSTAMP_H

#include "pet.h"

class PetStamp
{
public:
    PetStamp(Pet p,long count)
    :pet(p)
    {
        this->count=count;
    }
    Pet getPet()
    {
        return pet;
    }
    long getCount()
    {
        return count;
    }
    string getPetType()
    {
        return pet.getPetType();
    }
private:
    Pet pet;
    long count;
};
#endif
