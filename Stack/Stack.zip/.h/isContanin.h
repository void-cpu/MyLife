#include<iostream>
#include<vector>
using namespace std; 

bool isContanin(vector<vector<int> >& matrix, int k){
	int row = 0;
    int col = matrix[0].size() - 1;
    while(row < matrix.size() && col > -1)
    {
       	if(matrix[row][col] == k)
            return true;
       	else if(matrix[row][col] > k)
            --col;
        else
            ++row;
    }
    return false;
};

