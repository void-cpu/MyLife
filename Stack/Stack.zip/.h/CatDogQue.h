#ifndef _CATDOGQUE_H
#define _CATDOGQUE_H

#include "pet.h"
#include "petstamp.h"
#include <queue>
#include<iostream>
using namespace std;

class CatDogQue
{
public:
    CatDogQue();
    void push(Pet pet);    
    Pet popAll();
    Dog popDog();
    Cat popCat();
    bool isEmpty();
    bool isDogEmpty();
    bool isCatEmpty();
private:
    queue<PetStamp> dogQ;
    queue<PetStamp> catQ;
    long count;
};
#endif
CatDogQue::CatDogQue()
{
    count = 0;
}

void CatDogQue::push(Pet pet)
{
    if("dog" == pet.getPetType())
        dogQ.push(PetStamp(pet,count++));
    else if("cat" == pet.getPetType())
        catQ.push(PetStamp(pet,count++));
    else
        cout<<"err,not dog or cat!";
    return ;
}

Pet CatDogQue::popAll()
{
    if(!catQ.empty() && !dogQ.empty())
    {
        if(dogQ.front().getCount() < catQ.front().getCount())
        {
            Pet tmp = dogQ.front().getPet();
            dogQ.pop();
            return tmp;
        }
        else
        {
            Pet tmp = catQ.front().getPet();
            catQ.pop();
            return tmp;
        }
    }
    else if (!catQ.empty())
    {
        Pet tmp = catQ.front().getPet();
        catQ.pop();
        return tmp;
    }
    else if (!dogQ.empty())
    {
        Pet tmp = dogQ.front().getPet();
        dogQ.pop();
        return tmp;
    }
    else 
    {
        cout<<"Error,empty queue!";
    }
}


Dog CatDogQue::popDog()
{
    if (!dogQ.empty())
    {
        Pet tmpP = dogQ.front().getPet();
        Dog tmpD;
        Pet *pd = &tmpD;
        *pd = tmpP;
        
        dogQ.pop();
        return tmpD;
    }
    else 
    {
        cout<<"Error,empty dog queue!";
    }
}


Cat CatDogQue::popCat()
{
    if (!catQ.empty())
    {
        Pet tmpP = catQ.front().getPet();
        Cat tmpC;
        Pet *pc = &tmpC;
        *pc = tmpP;
        
        catQ.pop();
        return tmpC;
    }
    else 
    {
        cout<<"Error,empty cat queue!";
    }
}

bool CatDogQue::isEmpty()
{
    return dogQ.empty() && catQ.empty();
}


bool CatDogQue::isDogEmpty()
{
    return dogQ.empty();
}

bool CatDogQue::isCatEmpty()
{
    return catQ.empty();
}
