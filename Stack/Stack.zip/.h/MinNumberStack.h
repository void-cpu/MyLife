#include<iostream>
#include<stack>
using namespace std;

class MaxNumberStack{
	public:
 
    stack<int> stack1,stack2;
    
    
    void push(int number) {
        
        stack1.push(number);
        if(stack2.empty())
            stack2.push(number);
        else if( number  <= stack2.top())
            stack2.push(number);
    }
   
    int pop() {
        int num1;
        
        if(stack1.top()==stack2.top())
        {  
            stack1.pop(); 
            num1 =  stack2.top();
            stack2.pop();
        }else
        {
           num1 = stack1.top();
           stack1.pop();
        }
        return num1;
    }
   
    int min() {
        int num = stack2.top();
        return  num;
    }
};

