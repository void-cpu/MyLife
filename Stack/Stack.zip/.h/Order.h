#include<iostream>

using namespace std;

struct node {
    int Number;
    struct node* Left;
    struct node* Right;
};

int maxHeight(node *root) {
    if(root==NULL){
        return 0;
    }
    int nLeft=maxHeight(root->Left);
    int nRight=maxHeight(root->Right);
    return nLeft>nRight?nLeft+1:nRight+1;
}


void PrintList(int Number)
{
    printf("%d ", Number);
}

void PreOrder(struct node* root)
{
    if (root == NULL)
        return;
    PrintList(root->Number);
    PreOrder(root->Left);
    PreOrder(root->Right);
}

void InOrder(struct node* root)
{
    if (root == NULL)
        return;
    InOrder(root->Left);
    PrintList(root->Number);
    InOrder(root->Right);
}

void PostOrder(struct node* root)
{
    if (root == NULL)
        return;
    PostOrder(root->Left);
    PostOrder(root->Right);
    PrintList(root->Number);
}

void PrintHeight(struct node *p, int Height)
 {
  if (!p) return;
  if (Height == 1) {
    PrintList(p->Number);
  } else {
    PrintHeight(p->Left, Height-1);
    PrintHeight(p->Right, Height-1);
  }
}

void PrintHeightOrder(struct node *root)
{
  int height = maxHeight(root);  //maxHeight����������߶ȣ��������ʵ���߶�Ϊ3
  for (int Height = 1; Height <= height; Height++) {
    PrintHeight(root,Height);
    printf("\n");
  }
}

int GetMaxWidth(struct node*pointer){
    int width[10];//��������������߶Ȳ�����10
    int maxWidth=0;
    int floor=1;
    if(pointer){
        width[floor]++;
        floor++;
        if (pointer->Left)
            width[floor]++;
        if (pointer->Right)
            width[floor]++;
        if(maxWidth<width[floor])
            maxWidth=width[floor];
        GetMaxWidth(pointer->Left);
        floor--;//�ǵ��˻�һ�㣬������������Ϊ�Ѿ�Get���ˣ�����Ҫ��ʱ�ķ��ء�
        GetMaxWidth(pointer->Right);
    }
    return maxWidth;
}

