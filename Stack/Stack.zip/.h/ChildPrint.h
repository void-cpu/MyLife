#include<iostream>
#include<vector>

using namespace std;
    
class Print{
	public:
		vector<int> printMatrix(vector<vector<int> > Array, int n, int m);
		void PrintLeven(vector<vector<int> > Array, int tr,int tc,int dr,int dc,bool f); 
		void PrintZhi(vector<vector<int> > Array);
	private:
		vector< vector<int> >Array;
};	


vector<int> Print::printMatrix(vector<vector<int> > Array, int n, int m) {
    vector<int>ans;
    int dir = 1;
         
    for(int i=0;i<n;i++){
        if(dir>0)
        {
            for(int j=0;j<m;j++)ans.push_back(Array[i][j]);
        }else{
            for(int j=m-1;j>=0;j--)ans.push_back(Array[i][j]);
        }
        
        dir = -1 * dir;
    }
    
	return ans;
}

void Print:: PrintLeven(vector<vector<int> > Array, int tr,int tc,int dr,int dc,bool f){
	if(f){
		while(tr!=dr+1){
			cout<<Array[tr++][tc--]<<" ";
		}
	}else{
		while(dr!=tr-1){
			cout<<Array[dr--][dc++]<<" ";
		}
	}
}

void Print:: PrintZhi(vector<vector<int> > Array){
	int Aa,Ab,Ba,Bb;
	int ENDR=Array.size()-1;
	int ENDC=Array[0].size()-1;
	bool FormUp=false;
	
	while(Aa!=ENDR+1){
		PrintLeven(Array,Aa,Ab,Ba,Bb,FormUp);
		Aa=Ab==ENDC?Aa+1:Aa;
		Ab=Ab==ENDC?Ab:Ab+1;
		Bb=Bb==ENDR?Bb+1:Bb;
		Ba=Ba==ENDR?Ba:Ba+1;
		FormUp=!FormUp;
	}
	cout<<endl;
} 

