#include<iostream>
#include<vector>
using namespace std;

class RotationPrintArray{
    public:
    	void printEdgeprintEdge(vector< vector<int> >m, int tR, int tC, int dR, int dC);
		void spiralOrderPrint(vector< vector<int> >matrix); 
		void Rotate(vector<vector<int> >& matrix); 
};

void RotationPrintArray::Rotate(vector<vector<int> >& matrix){
	if(matrix.empty()){
		return;
	}else{
		int tmp;
        int m=matrix.size();
        int n=matrix[0].size();
    	for(int i=0;i<m/2;i++){
        	for(int j=i+1;j<n-i;j++){
            	tmp=matrix[i][j];
            	matrix[i][j]=matrix[n-1-j][i];
            	matrix[n-1-j][i]=matrix[n-1-i][n-1-j];
            	matrix[n-1-i][n-1-j]=matrix[j][n-1-i];
            	matrix[j][n-1-i]=tmp;
    		}
		}
    }
}

void  RotationPrintArray::spiralOrderPrint(vector< vector<int> >matrix) {
    int tR = 0;
   	int tC = 0;
   	int dR = matrix.size()- 1;
    int dC = matrix[0].size() - 1;
    while (tR <= dR && tC <= dC) {
        printEdgeprintEdge(matrix, tR++, tC++, dR--, dC--);
    }
}

void RotationPrintArray::printEdgeprintEdge(vector< vector<int> >m, int tR, int tC, int dR, int dC) {
    int  times=dC-tC;
    int tmp=0; 		
    for(int i=0;i!=times;i++){
		tmp=m[tR][tC+i];
       	m[tR][tC+i]=m[dR-i][tC];
		m[dR-i][tC]=m[dR][dC-i];
		m[dR][dC-i]=m[tR+i][dC];
		m[tR+i][dC]=tmp;
	}

}
