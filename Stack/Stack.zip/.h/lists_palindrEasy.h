#include <iostream>
#include <stack>
using namespace std;

struct Node
{
    int value;
    Node *next;
};

bool isPalindrome1(Node *head)
{
    stack<Node> s;
    Node *cur = head;
    while(NULL != cur)
    {
        s.push(*cur);    //�������ڵ�ȫ��ѹ��ջ��
        cur  = cur->next;
    }
    while(NULL != head)
    {
        if(head->value != s.top().value)
            return false;
        s.pop();
        head = head->next;
    }
    return true;
}

//ʹ��ջ���Ż��㷨
bool isPalindrome2(Node *head)
{
    if(NULL == head || NULL == head->next)
        return true;
    Node *right = head->next;
    Node *cur = head;
    while(NULL != cur->next && NULL != cur->next->next)
    {
        right = right->next;
        cur = cur->next->next;
    }
    stack<Node> s;
    while(NULL != right)
    {
        s.push(*right);        //���������Ұ벿��ѹ��ջ
        right = right->next;
    }
    while(!s.empty())
    {
        if(head->value != s.top().value)
            return false;
        s.pop();
        head = head->next;
    }
    return true;
}
