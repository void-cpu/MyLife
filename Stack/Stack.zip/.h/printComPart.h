#include <iostream>

using namespace std;

struct Node
{
    int value;
    Node *next;
};

void printComPart(Node *head1,Node *head2)
{
    cout << "Common Part: " << endl;
    while(NULL != head1 && NULL != head2)
    {
        if(head1->value < head2->value)
            head1 = head1->next;
        else if(head1->value > head2->value)
            head2 = head2->next;
        else
        {
            cout << head1->value << " " ;
            head1 = head1->next;
            head2 = head2->next;
        }
    }
    cout << endl;
}
