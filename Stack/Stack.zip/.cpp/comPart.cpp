#include <iostream>
#include"printComPart.h"
using namespace std;

int main()
{
    Node *head1 = NULL;
    Node *head2 = NULL;
    Node *ptr = NULL;
    
    for(int i =0;i<10;i++)
    {
        if(NULL == head1)
        {    
            head1 = new Node;
            head1->value = i;
            head1->next = NULL;
            ptr = head1;
            continue;
        }
        ptr->next = new Node;
        ptr = ptr->next;
        ptr->value = i;
        ptr->next = NULL;
    }
    for(int i =3;i<23;i++)
    {
        if(NULL == head2)
        {    
            head2 = new Node;
            head2->value = i;
            head2->next = NULL;
            ptr = head2;
            continue;
        }
        ptr->next = new Node;
        ptr = ptr->next;
        ptr->value = i;
        ptr->next = NULL;
    }
    printComPart(head1,head2);
    return 0;
}
