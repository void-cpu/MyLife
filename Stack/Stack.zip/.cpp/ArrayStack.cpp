#include "MyStack.h"
#include <iostream>
using namespace std;

int main(void)
{
	MyStack *pStack = new MyStack(5); 
	
	pStack->push('h');//ջ��
	pStack->push('e');
	pStack->push('l');
	pStack->push('l');
	pStack->push('o');//ջ��
	if (pStack->stackFull()){
		cout << "ջ��" << endl;
	}
	pStack->stackTraverse(true);
	cout << endl;
 
	char ch;
	pStack->pop(ch);
	cout << ch << endl;
	if (pStack->stackEmpty()){
		cout << "ջ��" << endl;
	}
	if (pStack->stackFull()){
		cout << "ջ��" << endl;
	}
	pStack->stackTraverse(false);
 
	cout << pStack->stackLength() << endl;
	pStack->clearStack();
	if (pStack->stackEmpty()){
		cout << "ջ��" << endl;
	}
	delete pStack;
	pStack = NULL;
	system("pause");
	return 0;
}
