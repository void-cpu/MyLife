#include "CatDogQue.h"
#include <iostream>

using namespace std;

int main()
{
    CatDogQue cdq;
    if(cdq.isEmpty())
        cout << "All queue is empty!" << endl;
    cdq.push(Dog());
    if(!cdq.isDogEmpty())
        cout << "Dog queue is not empty!" << endl;
    if(cdq.isCatEmpty())
        cout << "Cat queue is Empty!" << endl;
    for(int i=0;i<2;i++)
    {
        cdq.push(Cat());
        cdq.push(Dog());
    }
    cout << "popAll:" << cdq.popAll().getPetType() << endl;
    cout << "popDog:" << cdq.popDog().getPetType() << endl;
    cout << "popCat:" << cdq.popCat().getPetType() << endl;    
    cout << "popAll:" << cdq.popAll().getPetType() << endl;
    cout << "popAll:" << cdq.popAll().getPetType() << endl;
    if(cdq.isEmpty())
        cout << "All queue is empty!" << endl;

    return 0;
}
