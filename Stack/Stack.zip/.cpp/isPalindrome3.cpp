#include <iostream>
#include <stack>
using namespace std;

int main()
{
    Node *head1 = NULL;
    Node *head2 = NULL;
    Node *ptr = NULL;
    
    for(int i =1;i<6;i++)//��������
    {
        if(NULL == head1)
        {    
            head1 = new Node;
            head1->value = i;
            head1->next = NULL;
            ptr = head1;
            continue;
        }
        ptr->next = new Node;
        ptr = ptr->next;
        ptr->value = i;
        ptr->next = NULL;
    }
    printLists(head1);
    if(isPalindrome1(head1) && isPalindrome2(head1) && isPalindrome3(head1) )
        cout << "Head1 is a palindrome list!" << endl;
    else
        cout << "Head1 is not a palindrome list!" << endl;
    Node *right = NULL;
    Node *tmp = NULL;
    for(int i =1;i<5;i++)//������Ľṹ������
    {
        if(NULL == head2 && NULL == right)
        {    
            head2 = new Node;
            head2->value = i;
            head2->next = NULL;
            ptr = head2;
            
            right = new Node;
            right->value = 5-i;
            right->next = NULL;
            tmp = right;
            continue;
        }
        ptr->next = new Node;
        ptr = ptr->next;
        ptr->value = i;
        ptr->next = NULL;
        
        tmp->next = new Node;
        tmp = tmp->next;
        tmp->value =5-i;
        tmp->next = NULL;
    }
    ptr->next = right;
    printLists(head2);
    if(isPalindrome1(head2) || isPalindrome2(head2) || isPalindrome3(head2) )
        cout << "Head2 is a palindrome list!" << endl;
    else
        cout << "Head2 is not a palindrome list!" << endl;

    return 0;
}
