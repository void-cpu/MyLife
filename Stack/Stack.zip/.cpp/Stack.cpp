# include <iostream>
# include <stack>

using namespace std;

int main()
{
    stack<int>Stack;
    
    for (int i = 1; i <= 5; i++){
        Stack.push(i);
    }

    for (int i = 1; i <= 5; i++) {
        cout << Stack.top() << endl;
		Stack.pop();
    }

    cout<<"the Stack is NULL."<<endl;
}
