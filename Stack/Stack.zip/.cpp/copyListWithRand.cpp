#include <iostream>
#include <hash_map>

using namespace std;
using namespace __gnu_cxx;

struct Node
{
    int value;
    Node *next;
    Node *rand;
};

//ʹ��hash_map����Ҫ��hash����
struct hash_Node
{
    size_t operator() (const Node &node) const
    {
        return node.value;
    }
};

//ʹ��hash_map����Ҫ�ıȽϺ���
struct compare_Node
{
    bool operator() (const Node &n1,const Node &n2) const
    {
        return n1.value == n2.value && n1.next == n2.next && n1.rand == n2.rand;
    }
};

//ʹ��hash_map�������
Node* copyListWithRand1(Node *head)
{
    hash_map<Node,Node,hash_Node,compare_Node> map;
    Node *cur = head;
    while(NULL != cur)
    {
        Node *ptr = new Node;
        ptr->value = cur->value;
        ptr->next = NULL;
        ptr->rand = NULL;
        map[*cur] = *ptr;    //һһ��Ӧ�Ĺ�ϵ
        cur = cur->next;
    }
    cur = head;
    while(NULL != cur)
    {
        map[*cur].next = cur->next;
        map[*cur].rand = cur->rand;
        cur = cur->next;
    }
    return &map[*head];
}

Node* copyListWithRand2(Node *head)
{
    if(NULL == head)
        return NULL;
    Node *cur = head;
    Node *next = NULL;
    while(NULL != cur)
    {
        next = new Node;
        next->value = cur->value;
        next->next = cur->next;
        next->rand = NULL;
        cur->next = next;
        cur = next->next;
    }

    cur = head;
    Node *curCopy = NULL;
    while(NULL != cur)    //����rand
    {
        next = cur->next->next;
        curCopy = cur->next;
        curCopy->rand = NULL != cur->rand ? cur->rand->next : NULL;
        cur = next;
    }

    Node *res = head->next;
    cur = head;
    while(NULL != cur)
    {
        next = cur->next->next;
        curCopy = cur->next;
        cur->next = next;
        curCopy->next = NULL != next ? next->next : NULL;
        cur = next;
    }
    return res;
}

void printListWithRand(Node *head)
{
    while(NULL != head)
    {
        if(NULL != head->rand)
            cout << head->value << " rand is: " << head->rand->value << endl;
        else
            cout << head->value << " rand is: NULL " << endl;

        if(NULL != head->next)
            cout << head->value << " next is: " << head->next->value << endl;
        else
            cout << head->value << " next is: NULL " << endl;
        head = head->next;
    }
}

int main()
{
    Node *head = NULL;
    Node *ptr = NULL;

    for(int i =0;i<4;i++)//��������
    {
        if(NULL == head)
        {
            head = new Node;
            head->value = i;
            head->next = NULL;
            head->rand = NULL;
            ptr = head;
            continue;
        }
        ptr->next = new Node;
        ptr->rand = ptr->next;
        ptr = ptr->next;
        ptr->value = i;
        ptr->next = NULL;
        ptr->rand = NULL;
    }

    cout << "before copy:" << endl;
    printListWithRand(head);

    cout << "Using hash_map to copy:" << endl;
    ptr = copyListWithRand1(head);
    printListWithRand(ptr);

    cout << "Using advanced algorithm to copy:" << endl;
    ptr = copyListWithRand2(head);
    printListWithRand(ptr);
    return 0;
}
