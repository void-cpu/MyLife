#include <iostream>
#include<stdlib.h>

using namespace std;

class Node
{
public:
    Node(int data)
    {
        value = data;
        next = NULL;
    }
public:
    int value;
    Node *next;
};

//找到入环节点
Node* getLoopNode(Node *head)
{
    if(NULL == head || NULL == head->next || NULL == head->next->next)
        return NULL;
    Node *n1 = head->next;
    Node *n2 = head->next->next;
    while(n1 != n2)
    {
        if(NULL == n2->next || NULL == n2->next->next)
            return NULL;
        n2 = n2->next->next;
        n1 = n1->next;
    }
    n2 = head;
    while(n1 != n2)
    {
        n1 = n1->next;
        n2 = n2->next;
    }
    return n1;
}

//不带环的链表的相交节点
Node* noLoop(Node *head1,Node *head2)
{
    if(NULL == head1 || NULL == head2)
        return NULL;
    Node *cur1 = head1;
    Node *cur2 = head2;
    int n = 0;
    
    while(NULL != cur1->next)
    {
        n++;
        cur1 = cur1->next;
    }
    while(NULL != cur2->next)
    {
        n--;
        cur2 = cur2->next;
    }

    if(cur1 != cur2)    //若最后一个节点不想等，则俩链表不相交
        return NULL;
    
    cur1 = n > 0 ? head1 : head2;
    cur2 = cur1 == head1 ? head2 : head1;
    n = abs(n);
    while(0 != n)  //以较短的那个链表为准
    {
        n--;
        cur1 = cur1->next;
    }
    while(cur1 != cur2)
    {
        cur1 = cur1->next;
        cur2 = cur2->next;
    }
    return cur1;
}

//带环链表的相交节点的判断
Node* bothLoop(Node *head1,Node *loop1,Node *head2,Node *loop2)
{
    Node *cur1(NULL),*cur2(NULL);
    
    if(loop1 == loop2)    //与不带环的相交节点的判断一样的
    {
        cur1 = head1;
        cur2 = head2;
        int n = 0;
        while(cur1 != loop1)
        {
            n++;
            cur1 = cur1->next;
        }

        while(cur2 != loop2)
        {
            n--;
            cur2 = cur2->next;
        }
        cur1 = n > 0 ? head1 : head2;
        cur2 = cur1 == head1 ? head2 : head1;
        n = abs(n);
        while(0 != n)
        {
            n--;
            cur1 = cur1->next;
        }
        while(cur1 != cur2)
        {
            cur1 = cur1->next;
            cur2 = cur2->next;
        }
        return cur1;
    }
    else
    {
        cur1 = loop1->next;
        while(cur1 != loop1)
        {
            if(cur1 == loop2)
                return loop2;
            cur1 = cur1->next;
        }
        return NULL;
    }
}

Node* getIntersectNode(Node *head1,Node *head2)
{
    if(NULL == head1 || NULL == head2)
        return NULL;
    Node *loop1 = getLoopNode(head1);
    Node *loop2 = getLoopNode(head2);
    if(NULL == loop1 && NULL == loop2)
        return noLoop(head1,head2);
    if(NULL != loop1 && NULL != loop2)
        return bothLoop(head1,loop1,head2,loop2);
    return NULL;
}


int main()
{
    Node *head1 = NULL;
    Node *head2 = NULL;
    Node *ptr1 = NULL;
    Node *ptr2 = NULL;
    Node *head3 = NULL;
    Node *ptr3 = NULL;
    for(int i =0;i<4;i++)//构造链表
    {
        if(NULL == head1 || NULL == head2)
        {    
            head1 = new Node(i);
            head1->next = NULL;
            ptr1 = head1;
            head2 = new Node(i);
            head2->next = NULL;
            ptr2 = head2;
            head3 = new Node(10-i);
            head3->next = NULL;
            ptr3 = head3;
            continue;
        }
        ptr1->next = new Node(i);
        ptr1 = ptr1->next;
        ptr1->next = NULL;
        ptr2->next = new Node(i);
        ptr2 = ptr2->next;
        ptr2->next = NULL;
        ptr3->next = new Node(10-i);
        ptr3 = ptr3->next;
        ptr3->next = NULL;
    }
    //第一：无环不相交
    if(NULL == getIntersectNode(head1,head2))
        cout << "Two lists are not intersecting!" << endl;
    //第二：有环不相交
    ptr1->next = head1->next;
    ptr2->next = head2->next;
    if(NULL == getIntersectNode(head1,head2))
        cout << "Two lists are not intersecting!" << endl;    
    //第三：无环相交
    ptr1->next = head3;
    ptr2->next = head3;
    if(NULL != getIntersectNode(head1,head2))
        cout << "Two lists are intersecting!" << getIntersectNode(head1,head2)->value << endl;
    //第四有环相交
    ptr3->next = head3;
    if(NULL != getIntersectNode(head1,head2))
        cout << "Two lists are intersecting!" << getIntersectNode(head1,head2)->value << endl;
    return 0;
}