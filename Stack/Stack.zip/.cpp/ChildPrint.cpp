#include<iostream>
#include<vector>

using namespace std;
    vector<int> printMatrix(vector<vector<int> > mat, int n, int m) {
        // write code here
        vector<int>ans;
        int dir = 1;
         
        for(int i=0;i<n;i++)
            {
            if(dir>0)
                {
                for(int j=0;j<m;j++)ans.push_back(mat[i][j]);
            }
            else
                {
                for(int j=m-1;j>=0;j--)ans.push_back(mat[i][j]);
            }
            dir = -1 * dir;
        }
        return ans;
    }
