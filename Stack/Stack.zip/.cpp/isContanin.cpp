#include <iostream>
#include <vector>
#include"isContanin.h"
using namespace std;

int main()
{
    int a[] = {0, 1, 2, 5};
    vector<int> ivec(a, a + 4);
    vector<vector<int> > m;
    m.push_back(ivec);
    ivec[0] = 2;
    ivec[1] = 3;
    ivec[2] = 4;
    ivec[3] = 7;
    m.push_back(ivec);
    bool returnisContanin=isContanin(m, 7);
    cout <<returnisContanin<< endl;
}

